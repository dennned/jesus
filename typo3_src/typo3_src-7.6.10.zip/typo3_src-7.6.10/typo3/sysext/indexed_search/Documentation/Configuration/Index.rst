﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt



.. _configuration:

Configuration
-------------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   General/Index
   TypoScript/Index

