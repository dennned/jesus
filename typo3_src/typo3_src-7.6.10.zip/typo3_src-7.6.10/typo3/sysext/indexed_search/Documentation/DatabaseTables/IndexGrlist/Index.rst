﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt



.. _index-grlist:

index\_grlist
^^^^^^^^^^^^^

This table will hold records related to a phash-row. Records in this
table confirms that certain gr\_lists would actually share the same
content as represented by phash-row - even though the phash-row may be
indexed under another login. The table is used during result-display
to positively confirm if the current user may see the resume (which
otherwise might contain secret info). Please see discussion far above.

