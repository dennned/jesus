﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt



.. _users-manual:

Users manual
------------

The extension has no user configuration. All configuration is created
and managed by the TYPO3 administrator.


