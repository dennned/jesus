﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt



.. _developer-s-guide:

Developer's Guide
-----------------

The Taskcenter makes it very easy to create a new task item.
Furthermore the implementations in the extensions sys\_action and
impexp but also in other extensions in the TER provide a good basis to
learn by example.


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   CreatingANewTask/Index
   TaskcenterApi/Index

